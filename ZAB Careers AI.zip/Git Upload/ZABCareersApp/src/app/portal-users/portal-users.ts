import { Component } from '@angular/core';

@Component({
  selector: 'app-portal-users',
  imports: [],
  templateUrl: './portal-users.html',
  styleUrl: './portal-users.css',
})
export class PortalUsers {

}
