import { AfterViewInit, Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-post-new-job',
  imports: [],
  templateUrl: './post-new-job.html',
  styleUrl: './post-new-job.css',
})
export class PostNewJob implements AfterViewInit {

  ngAfterViewInit(): void {
    (window as any).initPostJobEditors?.();
  }

}
