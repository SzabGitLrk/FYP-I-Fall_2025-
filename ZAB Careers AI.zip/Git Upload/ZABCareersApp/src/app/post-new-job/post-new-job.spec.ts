import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PostNewJob } from './post-new-job';

describe('PostNewJob', () => {
  let component: PostNewJob;
  let fixture: ComponentFixture<PostNewJob>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PostNewJob]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PostNewJob);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
