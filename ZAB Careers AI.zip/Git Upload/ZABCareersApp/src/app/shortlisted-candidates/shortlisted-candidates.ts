import { Component } from '@angular/core';

@Component({
  selector: 'app-shortlisted-candidates',
  imports: [],
  templateUrl: './shortlisted-candidates.html',
  styleUrl: './shortlisted-candidates.css',
})
export class ShortlistedCandidates {

}
