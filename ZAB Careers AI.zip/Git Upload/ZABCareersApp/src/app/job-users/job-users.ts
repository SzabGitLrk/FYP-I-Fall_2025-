import { Component } from '@angular/core';

@Component({
  selector: 'app-job-users',
  imports: [],
  templateUrl: './job-users.html',
  styleUrl: './job-users.css',
})
export class JobUsers {

}
