import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-active-jobs',
  imports: [RouterLink],
  templateUrl: './active-jobs.html',
  styleUrl: './active-jobs.css',
})
export class ActiveJobs {

}
