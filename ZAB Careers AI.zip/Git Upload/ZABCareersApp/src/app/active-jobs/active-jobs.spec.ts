import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ActiveJobs } from './active-jobs';

describe('ActiveJobs', () => {
  let component: ActiveJobs;
  let fixture: ComponentFixture<ActiveJobs>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ActiveJobs]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ActiveJobs);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
