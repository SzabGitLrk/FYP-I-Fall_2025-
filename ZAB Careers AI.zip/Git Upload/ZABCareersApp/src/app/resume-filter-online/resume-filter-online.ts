import { Component } from '@angular/core';

@Component({
  selector: 'app-resume-filter-online',
  imports: [],
  templateUrl: './resume-filter-online.html',
  styleUrl: './resume-filter-online.css',
})
export class ResumeFilterOnline {

}
