import { Component } from '@angular/core';

@Component({
  selector: 'app-users-messages',
  imports: [],
  templateUrl: './users-messages.html',
  styleUrl: './users-messages.css',
})
export class UsersMessages {

}
