import { HttpClient } from '@angular/common/http';
import { Component, OnInit, signal } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-roles',
  imports: [ReactiveFormsModule],
  templateUrl: './roles.html',
  styleUrl: './roles.css',
})
export class Roles implements OnInit {


  constructor(private http: HttpClient) {
  }

  ngOnInit(): void {
    this.ShowAllData();
  }

  ListofData = signal<any[]>([]);

  // Custom Methods - APIs End Point Logic
  ShowAllData(): void {
    this.http.get<any[]>("https://localhost:7274/api/Roles/GetAllRoles/").subscribe(
      {
        next: (res) => {
          this.ListofData.set(res);
          console.log(res);
        },
        error: (res) => {
          console.log("Error - Data Could Not Fetch." + res);
        }
      }
    );
  }

}
