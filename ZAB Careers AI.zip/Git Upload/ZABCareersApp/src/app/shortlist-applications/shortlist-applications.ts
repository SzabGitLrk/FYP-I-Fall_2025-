import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-shortlist-applications',
  imports: [RouterLink],
  templateUrl: './shortlist-applications.html',
  styleUrl: './shortlist-applications.css',
})
export class ShortlistApplications {

}
