import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShortlistApplications } from './shortlist-applications';

describe('ShortlistApplications', () => {
  let component: ShortlistApplications;
  let fixture: ComponentFixture<ShortlistApplications>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ShortlistApplications]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ShortlistApplications);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
