import { HttpClient } from '@angular/common/http';
import { Component, OnInit, signal } from '@angular/core';

@Component({
  selector: 'app-campuses',
  imports: [],
  templateUrl: './campuses.html',
  styleUrl: './campuses.css',
})
export class Campuses {


}
