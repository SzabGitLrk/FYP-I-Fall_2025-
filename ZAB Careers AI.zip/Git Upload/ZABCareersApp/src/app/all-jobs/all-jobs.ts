import { Component } from '@angular/core';

@Component({
  selector: 'app-all-jobs',
  imports: [],
  templateUrl: './all-jobs.html',
  styleUrl: './all-jobs.css',
})
export class AllJobs {

}
