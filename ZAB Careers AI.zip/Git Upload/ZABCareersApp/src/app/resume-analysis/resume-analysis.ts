import { Component } from '@angular/core';

@Component({
  selector: 'app-resume-analysis',
  imports: [],
  templateUrl: './resume-analysis.html',
  styleUrl: './resume-analysis.css',
})
export class ResumeAnalysis {

}
