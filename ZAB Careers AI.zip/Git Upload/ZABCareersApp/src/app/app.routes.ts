import { Routes } from '@angular/router';
import { AdminLayout } from './admin-layout/admin-layout';
import { Dashboard } from './dashboard/dashboard';
import { ActiveJobs } from './active-jobs/active-jobs';
import { AllJobs } from './all-jobs/all-jobs';
import { Campuses } from './campuses/campuses';
import { Departments } from './departments/departments';
import { JobUsers } from './job-users/job-users';
import { PortalUsers } from './portal-users/portal-users';
import { PostNewJob } from './post-new-job/post-new-job';
import { ResumeAnalysis } from './resume-analysis/resume-analysis';
import { ResumeFilterOnline } from './resume-filter-online/resume-filter-online';
import { Roles } from './roles/roles';
import { ShortlistApplications } from './shortlist-applications/shortlist-applications';
import { ShortlistedCandidates } from './shortlisted-candidates/shortlisted-candidates';
import { UsersMessages } from './users-messages/users-messages';
import { Error404 } from './error-404/error-404';
import { AdminLogin } from './admin-login/admin-login';

export const routes: Routes = [

    { path: 'admin/login', component: AdminLogin, title: 'Admin Login - ZAB Careers' },

    {
        path: 'admin', component: AdminLayout, children: [
            { path: 'dashboard', component: Dashboard, title: 'Dashboard - ZAB Careers' },
            { path: 'active-jobs', component: ActiveJobs, title: 'Active Jobs - ZAB Careers' },
            { path: 'all-jobs', component: AllJobs, title: 'All Jobs - ZAB Careers' },
            { path: 'campuses', component: Campuses, title: 'Campuses - ZAB Careers' },
            { path: 'departments', component: Departments, title: 'Departments - ZAB Careers' },
            { path: 'job-users', component: JobUsers, title: 'Job Users - ZAB Careers' },
            { path: 'portal-users', component: PortalUsers, title: 'Portal Users - ZAB Careers' },
            { path: 'post-new-job', component: PostNewJob, title: 'Post New Job - ZAB Careers' },
            { path: 'resume-analysis', component: ResumeAnalysis, title: 'Resume Analysis - ZAB Careers' },
            { path: 'resume-filter-online', component: ResumeFilterOnline, title: 'Resume Filter Online - ZAB Careers' },
            { path: 'roles', component: Roles, title: 'Roles - ZAB Careers' },
            { path: 'shortlist-applications', component: ShortlistApplications, title: 'Shortlist Applications - ZAB Careers' },
            { path: 'shortlisted-candidates', component: ShortlistedCandidates, title: 'Shortlisted Candidates - ZAB Careers' },
            { path: 'users-messages', component: UsersMessages, title: 'Users Message - ZAB Careers' }
        ]
    },

    { path: '**', component: Error404, title: 'Page Not Found - ZAB Careers' }

];
