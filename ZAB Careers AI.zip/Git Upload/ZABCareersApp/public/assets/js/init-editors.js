window.initPostJobEditors = function () {
    if (!window.ClassicEditor) return;

    const ids = [
        'editor-jd',
        'editor-r',
        'editor-ee',
        'editor-ob'
    ];

    ids.forEach(id => {
        const el = document.getElementById(id);

        if (el && !el.dataset.ckeditor) {
            ClassicEditor
                .create(el)
                .then(() => {
                    el.dataset.ckeditor = 'true'; // prevent double init
                })
                .catch(err => console.error(err));
        }
    });
};
