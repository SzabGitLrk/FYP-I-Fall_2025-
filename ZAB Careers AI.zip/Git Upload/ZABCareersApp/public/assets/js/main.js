console.log('MAIN.JS LOADED');

/* ------------------------------
   Slide helpers
------------------------------- */
function slideUp(el, duration = 300) {
    el.style.overflow = 'hidden';
    el.style.height = el.scrollHeight + 'px';
    requestAnimationFrame(() => {
        el.style.transition = `height ${duration}ms`;
        el.style.height = '0';
    });
    setTimeout(() => {
        el.style.display = 'none';
        el.style.height = '';
        el.style.transition = '';
        el.style.overflow = '';
    }, duration);
}

function slideDown(el, duration = 300) {
    el.style.display = 'block';
    el.style.overflow = 'hidden';
    el.style.height = '0';
    const h = el.scrollHeight;
    requestAnimationFrame(() => {
        el.style.transition = `height ${duration}ms`;
        el.style.height = h + 'px';
    });
    setTimeout(() => {
        el.style.height = '';
        el.style.transition = '';
        el.style.overflow = '';
    }, duration);
}

/* ------------------------------
   MAIN INITIALIZER (SPA SAFE)
------------------------------- */
window.initMainTemplate = function () {

    document.querySelectorAll('.sidebar-item.has-sub').forEach(item => {

        const link = item.querySelector(':scope > .sidebar-link');
        const submenu = item.querySelector(':scope > .submenu');
        if (!link || !submenu) return;

        /* ---- INITIAL STATE (FIX BLINK) ---- */
        if (!submenu.dataset.ready) {
            submenu.dataset.ready = 'true';
            submenu.style.display = 'none';
            submenu.classList.remove('active');
        }

        /* ---- BIND ONLY ONCE ---- */
        if (link.dataset.bound === 'true') return;
        link.dataset.bound = 'true';

        link.addEventListener('click', function (e) {

            // IMPORTANT:
            // Only prevent default for dropdown toggle
            // NOT for routerLink navigation
            if (!link.hasAttribute('routerLink')) {
                e.preventDefault();
            }

            e.stopPropagation();

            const isOpen = submenu.classList.contains('active');

            // Close other open submenus
            document.querySelectorAll('.submenu.active').forEach(sm => {
                if (sm !== submenu) {
                    sm.classList.remove('active');
                    slideUp(sm);
                }
            });

            if (!isOpen) {
                submenu.classList.add('active');
                slideDown(submenu);
            } else {
                submenu.classList.remove('active');
                slideUp(submenu);
            }
        });
    });

    /* ---- Burger toggle ---- */
    const sidebar = document.getElementById('sidebar');
    document.querySelectorAll('.burger-btn, .sidebar-hide').forEach(btn => {
        if (btn && !btn.dataset.bound) {
            btn.dataset.bound = 'true';
            btn.addEventListener('click', () => sidebar?.classList.toggle('active'));
        }
    });
};

/* ------------------------------
   RUN STRATEGY (Angular Routing)
------------------------------- */

// First page load
document.addEventListener('DOMContentLoaded', window.initMainTemplate);

// Re-run after Angular route changes
new MutationObserver(() => {
    window.initMainTemplate();
}).observe(document.body, { childList: true, subtree: true });
