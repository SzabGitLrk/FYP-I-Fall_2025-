(function () {
    function initDataTables() {
        if (!window.simpleDatatables) return;

        document.querySelectorAll('table#table1:not(.datatable-initialized)')
            .forEach(table => {
                new simpleDatatables.DataTable(table);
                table.classList.add('datatable-initialized');
            });
    }

    // Run on first load
    document.addEventListener('DOMContentLoaded', initDataTables);

    // Run after every route change / DOM update
    const observer = new MutationObserver(initDataTables);
    observer.observe(document.body, { childList: true, subtree: true });
})();
