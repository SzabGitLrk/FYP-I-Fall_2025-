﻿namespace ZABCareersAPIs.Models
{
    public class Role
    {
        public int RoleID { get; set; }
        public string? RoleName { get; set; }
        public int RoleStatus { get; set; }

        // Navigation
        public ICollection<User> Users { get; set; } = new List<User>();
    }

}
