﻿namespace ZABCareersAPIs.Models
{
    public class ResumeAnalysis
    {
        public int ResumeAnalysisId { get; set; }

        public int ApplicationID { get; set; }

        public float MatchedScore { get; set; }
        public string KeySkills { get; set; }
        public string RequiredSkills { get; set; }
        public string Experience { get; set; }
        public string SkillsMatched { get; set; }
        public string MissingSkills { get; set; }
        public string AISuggestions { get; set; }

        // Navigation
        public Application Application { get; set; } = null!;

    }
}
