﻿namespace ZABCareersAPIs.Models
{
    public class Campus
    {
        public int CampusID { get; set; }
        public string? CampusName { get; set; }
        public string? CampusLogo { get; set; }
        public string? CampusLocation { get; set; }
        public int CampusStatus { get; set; }

        // Navigation
        public ICollection<User> Users { get; set; } = new List<User>();
        public ICollection<Job> Jobs { get; set; } = new List<Job>();
    }

}
