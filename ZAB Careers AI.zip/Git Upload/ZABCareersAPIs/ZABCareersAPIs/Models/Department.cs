﻿namespace ZABCareersAPIs.Models
{
    public class Department
    {
        public int DepartmentID { get; set; }
        public string? DepartmentName { get; set; }
        public int DepartmentStatus { get; set; }

        // Navigation
        public ICollection<Job> Jobs { get; set; } = new List<Job>();
    }

}
