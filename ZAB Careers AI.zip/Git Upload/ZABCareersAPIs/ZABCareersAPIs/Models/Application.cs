﻿namespace ZABCareersAPIs.Models
{
    public class Application
    {
        public int ApplicationID { get; set; }

        // Foreign Keys
        public int JobID { get; set; }
        public int CandidateID { get; set; }
        public int ApplicationStatus { get; set; }

        // Navigation
        public Job Job { get; set; } = null!;
        public Candidate Candidate { get; set; } = null!;

        // Navigation
        public ICollection<ResumeAnalysis> ResumeAnalysis { get; set; } = new List<ResumeAnalysis>();
    }

}
