﻿namespace ZABCareersAPIs.Models
{
    public class User
    {
        public int UserID { get; set; }
        public string? UserName { get; set; }
        public string? UserEmail { get; set; }
        public string? UserPassword { get; set; }
        public int UserStatus { get; set; }

        // Foreign Keys
        public int RoleID { get; set; }
        public int CampusID { get; set; }

        // Navigation
        public Role Role { get; set; } = null!;
        public Campus Campus { get; set; } = null!;
    }

}
