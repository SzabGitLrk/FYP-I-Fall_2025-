﻿using static System.Net.Mime.MediaTypeNames;

namespace ZABCareersAPIs.Models
{
    public class Candidate
    {
        public int CandidateID { get; set; }
        public string? CandidateName { get; set; }
        public string? CandidateEmail { get; set; }
        public string? CandidatePassword { get; set; }
        public string? Mobile { get; set; }
        public string? Resume { get; set; }
        public int CandidateStatus { get; set; }

        // Navigation
        public ICollection<Application> Applications { get; set; } = new List<Application>();
    }

}
