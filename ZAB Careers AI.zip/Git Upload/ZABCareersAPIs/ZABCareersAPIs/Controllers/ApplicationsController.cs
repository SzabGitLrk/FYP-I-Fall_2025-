﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ZABCareersAPIs.Data;
using ZABCareersAPIs.Models;

namespace ZABCareersAPIs.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ApplicationsController : ControllerBase
    {
        private readonly AppDbContext db;

        public ApplicationsController(AppDbContext _db)
        {
            db = _db;
        }

        [HttpGet("GetAllApplications")]
        public IActionResult GetAllApplications()
        {
            var data = db.Tbl_Applications.ToList();
            return Ok(data);
        }

        [HttpPost("AddApplication")]
        public IActionResult AddApplication([FromForm] Application application)
        {
            if (application == null)
            {
                return BadRequest();
            }
            else
            {
                db.Tbl_Applications.Add(application);
                db.SaveChanges();
                return Created();
            }
        }

        [HttpDelete("DeleteApplication/{Id}")]
        public IActionResult DeleteApplication(int Id)
        {
            var data = db.Tbl_Applications.Find(Id);

            if (data == null)
            {
                return NotFound();
            }
            else
            {
                db.Tbl_Applications.Remove(data);
                db.SaveChanges();
                return NoContent();
            }
        }

        [HttpGet("GetApplicationByID/{Id}")]
        public IActionResult GetApplicationByID(int Id)
        {
            var data = db.Tbl_Applications.Find(Id);

            if (data == null)
            {
                return NotFound();
            }
            else
            {
                return Ok(data);
            }
        }
    }
}
