﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ZABCareersAPIs.Migrations
{
    /// <inheritdoc />
    public partial class AddedResumeTable : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "AISuggestions",
                table: "Tbl_Applications");

            migrationBuilder.DropColumn(
                name: "Experience",
                table: "Tbl_Applications");

            migrationBuilder.DropColumn(
                name: "KeySkills",
                table: "Tbl_Applications");

            migrationBuilder.DropColumn(
                name: "MatchedScore",
                table: "Tbl_Applications");

            migrationBuilder.DropColumn(
                name: "MissingSkills",
                table: "Tbl_Applications");

            migrationBuilder.DropColumn(
                name: "RequiredSkills",
                table: "Tbl_Applications");

            migrationBuilder.DropColumn(
                name: "SkillsMatched",
                table: "Tbl_Applications");

            migrationBuilder.CreateTable(
                name: "Tbl_ResumeAnalysis",
                columns: table => new
                {
                    ResumeAnalysisId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ApplicationID = table.Column<int>(type: "int", nullable: false),
                    MatchedScore = table.Column<float>(type: "real", nullable: false),
                    KeySkills = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    RequiredSkills = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Experience = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    SkillsMatched = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    MissingSkills = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    AISuggestions = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tbl_ResumeAnalysis", x => x.ResumeAnalysisId);
                    table.ForeignKey(
                        name: "FK_Tbl_ResumeAnalysis_Tbl_Applications_ApplicationID",
                        column: x => x.ApplicationID,
                        principalTable: "Tbl_Applications",
                        principalColumn: "ApplicationID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Tbl_ResumeAnalysis_ApplicationID",
                table: "Tbl_ResumeAnalysis",
                column: "ApplicationID");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Tbl_ResumeAnalysis");

            migrationBuilder.AddColumn<string>(
                name: "AISuggestions",
                table: "Tbl_Applications",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Experience",
                table: "Tbl_Applications",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "KeySkills",
                table: "Tbl_Applications",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<float>(
                name: "MatchedScore",
                table: "Tbl_Applications",
                type: "real",
                nullable: false,
                defaultValue: 0f);

            migrationBuilder.AddColumn<string>(
                name: "MissingSkills",
                table: "Tbl_Applications",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "RequiredSkills",
                table: "Tbl_Applications",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "SkillsMatched",
                table: "Tbl_Applications",
                type: "nvarchar(max)",
                nullable: true);
        }
    }
}
